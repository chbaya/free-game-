----------------------------
addappid(2322010)
addappid(228988)
addappid(2322011,0,"78758c85a2a8b04770fb4fe430ac7a215a959b72e496d94f6a0ec5ac38066f49")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------