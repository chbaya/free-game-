----------------------------
addappid(12120)
addappid(228990)
addappid(12123,0,"b6246a66a369124f35879ade188971257e9827d14f178abace4d759001e6191a")
addappid(12122,0,"eaa6ab82216553e3e53f1de147e88096b378cbc8b0cd488fd2c4d047ff263389")
addappid(12121,0,"d89825855fd6f4b802378b6110effadaea8db612d89de6cf00f75dc92f898bf0")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------