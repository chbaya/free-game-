----------------------------
addappid(1501750)
addappid(228989)
addappid(228990)
addappid(1501751,0,"c86a5d17ac060ed8c27bc9840a5eb75890d5d8cf1908993635a947d13a30076b")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------