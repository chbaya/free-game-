----------------------------
addappid(1903340, 1, "302b1b9c8eb04ca24027876370a3072643790a12b835cabccaecb15b226075e8")

addappid(1903341, 1, "8593f9c4cd595f833d5344e55cd6c6fdb73d9a4fa05dab033ba71622265e8c82")


addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")


addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")


addappid(3228520)

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------