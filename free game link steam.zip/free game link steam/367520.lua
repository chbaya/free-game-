----------------------------
addappid(367520)
addappid(367521, 1, "de801b9b61e3385b333259cc0f04d2e5d976c4cb8f933cb859d75a4d0125a2a8")
addappid(367522, 1, "c7e67c6bf87d7128302920e88b17cb6ee322e69585472cbcd2a3d913c7d3579a")
addappid(367523, 1, "61dd4c0fd624c81feb31fc22cb61a228c4d8077cf3927e9058f736026d9dd838")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------