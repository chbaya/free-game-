----------------------------
addappid(648800)
addappid(228990)
addappid(648801,0,"69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------